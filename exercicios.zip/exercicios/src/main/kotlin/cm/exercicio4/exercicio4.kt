package org.example.cm.exercicio4

import kotlin.math.sqrt

data class Vec2(val x: Double, val y: Double) : Comparable<Vec2> {

    operator fun plus(other: Vec2): Vec2 {
        return Vec2(x + other.x, y + other.y)
    }

    operator fun minus(other: Vec2): Vec2 {
        return Vec2(x - other.x, y - other.y)
    }

    operator fun times(value: Double): Vec2 {
        return Vec2(x * value, y * value)
    }

    operator fun unaryMinus(): Vec2 {
        return Vec2(-x, -y)
    }

    override fun compareTo(other: Vec2): Int {
        return magnitude().compareTo(other.magnitude())
    }

    fun magnitude(): Double {
        return sqrt(x * x + y * y)
    }

    fun dot(other: Vec2): Double {
        return x * other.x + y * other.y
    }

    fun normalized(): Vec2 {
        val m = magnitude()

        if (m == 0.0) {
            throw IllegalStateException("Zero vector")
        }

        return Vec2(x / m, y / m)
    }

    operator fun get(index: Int): Double {
        if (index == 0) return x
        if (index == 1) return y
        throw IndexOutOfBoundsException("Invalid index")
    }
}

fun main() {
    val a = Vec2(3.0, 4.0)
    val b = Vec2(1.0, 2.0)

    println("a = $a")
    println("b = $b")
    println("a + b = ${a + b}")
    println("a - b = ${a - b}")
    println("a * 2.0 = ${a * 2.0}")
    println("-a = ${-a}")
    println("|a| = ${a.magnitude()}")
    println("a dot b = ${a.dot(b)}")
    println("norm(a) = ${a.normalized()}")
    println("a[0] = ${a[0]}")
    println("a[1] = ${a[1]}")
    println("a > b = ${a > b}")
    println("a < b = ${a < b}")

    val vectors = listOf(
        Vec2(1.0, 0.0),
        Vec2(3.0, 4.0),
        Vec2(0.0, 2.0)
    )

    println("Longest = ${vectors.max()}")
    println("Shortest = ${vectors.min()}")
}