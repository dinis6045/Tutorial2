        package org.example.cm.exercicio2

        class Cache<K : Any, V : Any> {  // K é o tipo da chave e V é o valor
            private val data = mutableMapOf<K, V>()  //Mutável guarda os dados assim  chave -> valor

            fun put(key: K, value: V) {
                data[key] = value  // Guarda o valor dentro do Map
            }

            fun get(key: K): V? {
                return data[key]
            }
            fun evict(key: K) {
                data.remove(key)
            }

            fun size(): Int {
                return data.size
            }

            fun getOrPut(key: K, default: () -> V): V {
                return data.getOrPut(key, default)
            }

            fun transform(key: K, action: (V) -> V): Boolean {
                if (data.containsKey(key)) {
                    data[key] = action(data[key]!!)
                    return true
                }
                return false
            }

            fun snapshot(): Map<K, V> {
                return data.toMap()
            }

            fun filterValues(predicate: (V) -> Boolean): Map<K, V> {
                return data.filterValues(predicate).toMap()
            }
        }

        fun main() {
            val wordCache = Cache<String, Int>() //String tipo de chave e INT valor
            wordCache.put("scala", 1)
            wordCache.put("haskell", 1)
            wordCache.put("java", 0)

            println("--- Word frequency cache ---")
            println("Size: ${wordCache.size()}")
            println("Frequency of \"kotlin\": ${wordCache.get("kotlin")}")
            println("getOrPut \"kotlin\": ${wordCache.getOrPut("kotlin") { 1 }}")
            println("getOrPut \"java\": ${wordCache.getOrPut("java") { 5 }}")
            println("Size after getOrPut: ${wordCache.size()}")
            println("Transform \"kotlin\" (+1): ${wordCache.transform("kotlin") { it + 1 }}")
            println("Transform \"cobol\" (+1): ${wordCache.transform("cobol") { it + 1 }}")
            println("Snapshot: ${wordCache.snapshot()}")

            println()
            println("Words with count > 0: ${wordCache.filterValues { it > 0 }}")

            println()
            val idCache = Cache<Int, String>()
            idCache.put(1, "Alice")
            idCache.put(2, "Bob")

            println("--- Id registry cache ---")
    println("Id 1 -> ${idCache.get(1)}")
    println("Id 2 -> ${idCache.get(2)}")

    idCache.evict(1)
    println("After evict id 1, size: ${idCache.size()}")
    println("Id 1 after evict -> ${idCache.get(1)}")
}