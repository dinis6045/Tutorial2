package org.example.cm.exercicio3

class Pipeline {
    private val stages = mutableListOf<Pair<String, (List<String>) -> List<String>>>()

    fun addStage(name: String, transform: (List<String>) -> List<String>) {
        stages.add(Pair(name, transform))
    }

    fun execute(input: List<String>): List<String> {
        var result = input

        for (stage in stages) {
            result = stage.second(result)  //função da etapa
        }

        return result
    }

    fun describe() {
        println("Pipeline stages:")
        for (i in stages.indices) {
            println("${i + 1}. ${stages[i].first}")  //nome da etapa 1st
        }
    }
}

fun buildPipeline(block: Pipeline.() -> Unit): Pipeline {
    val pipeline = Pipeline()
    pipeline.block() //executa dentro do pipline
    return pipeline
}





fun main() {
    val logs = listOf(
        " INFO: server started ",
        " ERROR: disk full ",
        " DEBUG: checking config ",
        " ERROR: out of memory ",
        " INFO: request received ",
        " ERROR: connection timeout "
    )

    val pipeline = buildPipeline {
        addStage("Trim") { lines ->
            lines.map { it.trim() }
        }

        addStage("Filter errors") { lines ->
            lines.filter { it.contains("ERROR") }
        }

        addStage("Uppercase") { lines ->
            lines.map { it.uppercase() }
        }

        addStage("Add index") { lines ->
            lines.mapIndexed { index, line ->
                "${index + 1}. $line"
            }
        }
    }

    pipeline.describe()

    val result = pipeline.execute(logs)

    println()
    println("Result:")
    for (line in result) {
        println(line)
    }
}