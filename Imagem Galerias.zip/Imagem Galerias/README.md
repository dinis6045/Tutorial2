# Imagem Galerias App

## Application purpose
An Android application that displays a gallery of images.

## API used
[Picsum Photos API](https://picsum.photos/v2/list)

## Screenshots
(Add screenshots here later once the app is running)

## Instructions for running the project
1. Open the project in Android Studio or AntiGravity IDE.
2. Sync the project with Gradle files.
3. Build and Run the project on an Android Emulator or physical device.
