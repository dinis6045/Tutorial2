# Features

1. Fetch images from API (Picsum)
2. Display images in a list
3. Refresh images
4. Show loading indicator
5. Show Image Details Screen
6. Support Favorite Items (FIFO queue max 5)
7. Maintain a cache of up to 50 items
8. Support Offline Access
9. Handle API errors gracefully
