Describe navigation between screens.

MainActivity (Main Screen)
       ↓
ImageDetailsActivity (Image Details Screen)
