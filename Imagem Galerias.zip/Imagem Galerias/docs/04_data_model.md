Define data structures used by the app.

ImageItem

id: String
author: String
width: Int
height: Int
url: String
download_url: String
