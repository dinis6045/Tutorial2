# Feature Extensions

## 1. MVVM Architecture
- **Description:** Ensure the application follows the MVVM pattern rigorously.
- **Implementation Tasks:** Refactor existing code to separate UI, ViewModel, Repository, and API layers.
- **UI Changes:** None.

## 2. Loading Indicator
- **Description:** Display a progress bar while data is being fetched.
- **Implementation Tasks:** Add ProgressBar to layouts, update ViewModel state to expose loading status.
- **UI Changes:** ProgressBar visible during network requests.

## 3. Image Details Screen
- **Description:** A new screen to show more details about the selected image.
- **Implementation Tasks:** Create ImageDetailsActivity, pass image data via Intent, design layout.
- **UI Changes:** New Activity with full image and metadata.

## 4. Favorite Items (FIFO)
- **Description:** Support Favorite Items (FIFO queue with a max of 5). Direct access from any screen via their images.
- **Implementation Tasks:** Create a local persistent/in-memory FIFO queue for 5 items. Add favorite toggle in UI.
- **UI Changes:** Favorite icons on images, possible favorites drawer/bar.

## 5. Caching System
- **Description:** Cache up to 50 items (excluding favorites), keeping at least 10 ahead and 10 behind current position.
- **Implementation Tasks:** Implement Room Database or custom in-memory caching logic. Adjust API fetching based on current index.
- **UI Changes:** Loading indicators relative to cached data boundaries.

## 6. Offline Access
- **Description:** Support offline access to cached items and favorites.
- **Implementation Tasks:** Check network connectivity, fallback to local cache/database when offline.
- **UI Changes:** Toast or indicator showing offline mode.

## 7. Graceful API Error Handling
- **Description:** Handle API errors gracefully.
- **Implementation Tasks:** Catch network exceptions, display user-friendly error messages (Snackbar/Toast) and offer retry mechanisms.
- **UI Changes:** Error states with retry buttons.
