# Prompts Log

## Prompt 1
Goal: Create project documentation
Prompt used: User uploaded screenshots of the tutorial and requested to use Picsum API.
Result: Created initial Markdown documentation structure.
