Describe each screen.

Screen: Main Screen

Components:
- Toolbar (Application Title)
- RecyclerView with images (grid or list)
- Refresh button (to load new images)
- Loading indicator (Progress bar)

Screen: Image Details Screen

Components:
- Toolbar (Image details, Back button)
- Full-screen or large ImageView
- TextViews with more information (Author, Size, Link, etc.)
- Favorite button/icon
