Describe the architecture used.

Architecture: MVVM (Model-View-ViewModel)

Layers:
UI -> ViewModel -> Repository -> API Service
