Describe the external API.

API endpoint:
https://picsum.photos/v2/list

Example response:
[
    {
        "id": "0",
        "author": "Alejandro Escamilla",
        "width": 5000,
        "height": 3333,
        "url": "https://unsplash.com/photos/yC-Yzbqy7Bk",
        "download_url": "https://picsum.photos/id/0/5000/3333"
    }
]
