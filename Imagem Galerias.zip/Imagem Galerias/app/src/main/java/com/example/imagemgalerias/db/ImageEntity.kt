package com.example.imagemgalerias.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.imagemgalerias.model.ImageItem

@Entity(tableName = "images")
data class ImageEntity(
    @PrimaryKey val id: String,
    val author: String,
    val width: Int,
    val height: Int,
    val url: String,
    val download_url: String,
    var isFavorite: Boolean = false,
    var timestamp: Long = System.currentTimeMillis()
) {
    fun toImageItem(): ImageItem = ImageItem(id, author, width, height, url, download_url)
}

fun ImageItem.toEntity(): ImageEntity = ImageEntity(id, author, width, height, url, download_url)
