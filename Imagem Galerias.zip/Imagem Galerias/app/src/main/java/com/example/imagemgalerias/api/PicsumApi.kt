package com.example.imagemgalerias.api

import com.example.imagemgalerias.model.ImageItem
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface PicsumApi {
    @GET("v2/list")
    suspend fun getImages(
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 30
    ): Response<List<ImageItem>>
}
