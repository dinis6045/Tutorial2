package com.example.imagemgalerias.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface ImageDao {
    @Query("SELECT * FROM images WHERE isFavorite = 0 ORDER BY timestamp DESC LIMIT 50")
    suspend fun getCachedImages(): List<ImageEntity>

    @Query("SELECT * FROM images WHERE isFavorite = 1 ORDER BY timestamp ASC")
    suspend fun getFavorites(): List<ImageEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertImages(images: List<ImageEntity>)

    @Update
    suspend fun updateImage(image: ImageEntity)
    
    @Query("SELECT * FROM images WHERE id = :id LIMIT 1")
    suspend fun getImageById(id: String): ImageEntity?

    @Query("SELECT COUNT(*) FROM images WHERE isFavorite = 1")
    suspend fun getFavoritesCount(): Int

    @Query("SELECT * FROM images WHERE isFavorite = 1 ORDER BY timestamp ASC LIMIT 1")
    suspend fun getOldestFavorite(): ImageEntity?

    @Query("DELETE FROM images WHERE isFavorite = 0 AND id NOT IN (SELECT id FROM images WHERE isFavorite = 0 ORDER BY timestamp DESC LIMIT 50)")
    suspend fun deleteOldCache()
}
