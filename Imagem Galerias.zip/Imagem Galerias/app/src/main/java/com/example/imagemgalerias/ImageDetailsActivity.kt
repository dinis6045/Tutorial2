package com.example.imagemgalerias

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.imagemgalerias.databinding.ActivityImageDetailsBinding
import com.example.imagemgalerias.model.ImageItem
import com.example.imagemgalerias.viewmodel.ImageViewModel

class ImageDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityImageDetailsBinding
    private val viewModel: ImageViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val id = intent.getStringExtra("id") ?: ""
        val author = intent.getStringExtra("author") ?: ""
        val url = intent.getStringExtra("url") ?: ""
        val downloadUrl = intent.getStringExtra("download_url") ?: ""
        val width = intent.getIntExtra("width", 0)
        val height = intent.getIntExtra("height", 0)

        val item = ImageItem(id, author, width, height, url, downloadUrl)

        binding.tvAuthor.text = "Autor: $author"
        binding.tvSize.text = "Tamanho original: ${width}x${height}"
        
        Glide.with(this)
            .load(downloadUrl)
            .into(binding.imageView)

        binding.fabFavorite.setOnClickListener {
            viewModel.toggleFavorite(item)
            Toast.makeText(this, "Adicionado/Removido dos favoritos!", Toast.LENGTH_SHORT).show()
        }
    }
}
