package com.example.imagemgalerias.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.imagemgalerias.databinding.ItemImageBinding
import com.example.imagemgalerias.model.ImageItem

class ImageAdapter(private val onClick: (ImageItem) -> Unit) : RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {

    private var images = listOf<ImageItem>()

    fun setImages(images: List<ImageItem>) {
        this.images = images
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        val binding = ItemImageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ImageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        holder.bind(images[position])
    }

    override fun getItemCount(): Int = images.size

    inner class ImageViewHolder(private val binding: ItemImageBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ImageItem) {
            Glide.with(binding.root.context)
                .load(item.download_url)
                .into(binding.imageView)
                
            binding.root.setOnClickListener {
                onClick(item)
            }
        }
    }
}
