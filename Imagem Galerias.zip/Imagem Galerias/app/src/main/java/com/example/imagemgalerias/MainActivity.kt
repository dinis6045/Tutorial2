package com.example.imagemgalerias

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.imagemgalerias.adapter.ImageAdapter
import com.example.imagemgalerias.databinding.ActivityMainBinding
import com.example.imagemgalerias.viewmodel.ImageViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: ImageViewModel by viewModels()
    private val adapter = ImageAdapter { item ->
        val intent = Intent(this, ImageDetailsActivity::class.java).apply {
            putExtra("id", item.id)
            putExtra("author", item.author)
            putExtra("url", item.url)
            putExtra("download_url", item.download_url)
            putExtra("width", item.width)
            putExtra("height", item.height)
        }
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        setupRecyclerView()
        observeViewModel()

        binding.fabRefresh.setOnClickListener {
            viewModel.fetchImages(isRefresh = true)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menu?.add(0, 1, 0, "Todas as Imagens")
        menu?.add(0, 2, 0, "Apenas Favoritos")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> viewModel.showAll()
            2 -> viewModel.loadFavorites()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }

    private fun observeViewModel() {
        viewModel.images.observe(this) { images ->
            adapter.setImages(images)
            binding.recyclerView.scrollToPosition(0)
        }

        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
        
        viewModel.errorMsg.observe(this) { msg ->
            if (!msg.isNullOrEmpty()) {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
            }
        }
    }
}
