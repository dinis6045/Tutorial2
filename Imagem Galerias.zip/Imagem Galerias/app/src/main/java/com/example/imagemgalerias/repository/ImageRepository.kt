package com.example.imagemgalerias.repository

import com.example.imagemgalerias.api.RetrofitInstance
import com.example.imagemgalerias.db.ImageDao
import com.example.imagemgalerias.db.toEntity
import com.example.imagemgalerias.model.ImageItem

class ImageRepository(private val dao: ImageDao) {

    suspend fun getImages(isRefresh: Boolean = false): List<ImageItem>? {
        if (!isRefresh) {
            val cached = dao.getCachedImages()
            if (cached.isNotEmpty()) {
                return cached.map { it.toImageItem() }
            }
        }

        return try {
            val response = RetrofitInstance.api.getImages((1..10).random())
            if (response.isSuccessful) {
                val items = response.body() ?: emptyList()
                dao.insertImages(items.map { it.toEntity() })
                dao.deleteOldCache()
                items
            } else {
                dao.getCachedImages().map { it.toImageItem() }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            dao.getCachedImages().map { it.toImageItem() }
        }
    }
    
    suspend fun toggleFavorite(item: ImageItem): Boolean {
        val entity = dao.getImageById(item.id) ?: item.toEntity()
        if (entity.isFavorite) {
            entity.isFavorite = false
            dao.updateImage(entity)
            return false
        } else {
            if (dao.getFavoritesCount() >= 5) {
                val oldest = dao.getOldestFavorite()
                if (oldest != null) {
                    oldest.isFavorite = false
                    dao.updateImage(oldest)
                }
            }
            entity.isFavorite = true
            entity.timestamp = System.currentTimeMillis()
            dao.updateImage(entity)
            return true
        }
    }
    
    suspend fun getFavorites(): List<ImageItem> {
        return dao.getFavorites().map { it.toImageItem() }
    }
}
