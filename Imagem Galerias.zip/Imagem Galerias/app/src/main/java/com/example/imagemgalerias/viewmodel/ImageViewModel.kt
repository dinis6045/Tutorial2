package com.example.imagemgalerias.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.imagemgalerias.db.AppDatabase
import com.example.imagemgalerias.model.ImageItem
import com.example.imagemgalerias.repository.ImageRepository
import kotlinx.coroutines.launch

class ImageViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ImageRepository

    private val _images = MutableLiveData<List<ImageItem>>()
    val images: LiveData<List<ImageItem>> get() = _images

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    private val _errorMsg = MutableLiveData<String?>()
    val errorMsg: LiveData<String?> get() = _errorMsg

    private var showFavoritesOnly = false

    init {
        val dao = AppDatabase.getDatabase(application).imageDao()
        repository = ImageRepository(dao)
        fetchImages()
    }

    fun fetchImages(isRefresh: Boolean = false) {
        if (showFavoritesOnly) {
            loadFavorites()
            return
        }
        viewModelScope.launch {
            _isLoading.postValue(true)
            val result = repository.getImages(isRefresh)
            if (result.isNullOrEmpty()) {
                _errorMsg.postValue("Não foi possível carregar imagens (Modo Offline).")
            } else {
                _images.postValue(result!!)
            }
            _isLoading.postValue(false)
        }
    }

    fun toggleFavorite(item: ImageItem) {
        viewModelScope.launch {
            repository.toggleFavorite(item)
            if (showFavoritesOnly) loadFavorites()
        }
    }

    fun loadFavorites() {
        showFavoritesOnly = true
        viewModelScope.launch {
            _images.postValue(repository.getFavorites())
        }
    }

    fun showAll() {
        showFavoritesOnly = false
        fetchImages()
    }
}
