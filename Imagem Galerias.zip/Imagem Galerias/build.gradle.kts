plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    id("com.google.devtools.ksp") version "1.9.22-1.0.17" apply false
}

allprojects {
    layout.buildDirectory.set(File("C:/temp/ImagemGaleriasBuild/${project.name}"))
}
